No separate PDF or HTML file is included for this data analysis as all of the analysis and
documentation was written in the .ipynb file. All steps are documented by both code and
words, as the project is made to function as a presentation.

The dataset which was used for this project is the no show appointments, of which a copy
is included in the zip file.
